package progq2;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MovieTicketsTest {
    
    private MovieTickets movieTickets;

    @BeforeEach
    public void setUp() {
        movieTickets = new MovieTickets();
    }

    @Test
    public void calculateVAT_ReturnsCorrectVAT() {
        // Arrange
        String ticketPrice = "100.00";
        double expectedVAT = 14.0; // 14% of 100.00

        // Act
        double vat = movieTickets.calculateVAT("1", ticketPrice);

        // Assert
        assertEquals(expectedVAT, vat, 0.01, "VAT should be 14.0 for a ticket price of 100.00.");
    }

    @Test
    public void calculateVAT_ReturnsZeroForInvalidPrice() {
        // Arrange
        String invalidTicketPrice = "abc"; // Invalid price

        // Act
        double vat = movieTickets.calculateVAT("1", invalidTicketPrice);

        // Assert
        assertEquals(0, vat, "VAT should be 0 for an invalid ticket price.");
    }

    @Test
    public void dataValidation_ReturnsFalseForEmptyFields() {
        // Arrange
        String emptyNumberValue = "";
        String ticketPrice = "50.00";

        // Act & Assert
        assertFalse(movieTickets.dataValidation(emptyNumberValue, ticketPrice), "Data validation should fail for an empty number of tickets.");
        assertFalse(movieTickets.dataValidation("2", ""), "Data validation should fail for an empty ticket price.");
    }

    @Test
    public void dataValida
