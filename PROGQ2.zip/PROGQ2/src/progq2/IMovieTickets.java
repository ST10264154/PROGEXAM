
package progq2;


public interface IMovieTickets {
    
    double CalculateTotalTicketPrice(int numberOfTickets, double ticketPrice);
    boolean ValidateData(MovieTicketData movieTicketData);

    public static class MovieTicketData {

        public MovieTicketData() {
        }
    }
    
}
