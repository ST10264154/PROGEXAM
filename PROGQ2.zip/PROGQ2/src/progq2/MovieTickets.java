
package progq2;

interface IMovieTickets {
    boolean dataValidation(String numberValue, String ticketPrice);
}

public class MovieTickets implements IMovieTickets {

    private static final double VAT_PERCENTAGE = 14.0; // Define VAT percentage as a constant

    // Method that calculates the amount of VAT based on the ticket price
    public double calculateVAT(String numberValue, String ticketPrice) {
        try {
            double price = Double.parseDouble(ticketPrice);
            double vat = (VAT_PERCENTAGE / 100) * price; // Calculate VAT based on a 14% rate
            return vat;
        } catch (NumberFormatException e) {
            System.out.println("Invalid ticket price format.");
            return 0;
        }
    }

    @Override
    // This method checks if all requirements are met when accepting user information
    public boolean dataValidation(String numberValue, String ticketPrice) {
        // Check if numberValue or ticketPrice are empty
        if (numberValue.isEmpty() || ticketPrice.isEmpty()) {
            return false;
        }

        try {
            double price = Double.parseDouble(ticketPrice);
            double number = Double.parseDouble(numberValue);

            // Check if the number of tickets and ticket price are valid
            if (price <= 0 || number <= 0) {
                return false;
            }
        } catch (NumberFormatException e) {
            return false;
        }

        return true; // Return true if all validations pass
    }

    boolean DataValidiation(String numberValue, String comboBoxValues, String priceValue) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    
    
        
        
        //Learn Java basics while doing a VAT Calculation
        //Andre Vermeulen-2021
        //https://www.youtube.com/watch?v=KnXFJA7AByo
        //12 November 2024
    
    }

    double CalculateTotalVAT(String numberValue, String priceValue) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
  
}
