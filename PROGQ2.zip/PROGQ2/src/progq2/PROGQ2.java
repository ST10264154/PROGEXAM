
package progq2;


public class PROGQ2 {

    
    public static void main(String[] args) {
        
    }
    
}
