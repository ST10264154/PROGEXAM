package progq2;

// Imports required for file handling and logging
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PROGQ2GUI extends javax.swing.JFrame {
   
    String comboBoxValues;
    String numberValue;
    String priceValue;
    double VATValue;

    public PROGQ2GUI() {
        initComponents();
    }
       
    private void processInformationButton() {

        MovieTickets movietickets = new MovieTickets();
     
        // Retrieving values from the UI components
        comboBoxValues = ComboBox.getSelectedItem().toString();
        numberValue = numberTicketTextField.getText();
        priceValue = PriceTextField.getText();

        // Calculate VAT using the appropriate method
        VATValue = movietickets.calculateVAT(numberValue, priceValue);

        // Validate input data using the appropriate method
        boolean valid = movietickets.dataValidation(numberValue, priceValue);

        // Display data in the text area if validation passes
        if (valid) {
            ticketReportTextArea.append("MOVIE: " + comboBoxValues + "\n");
            ticketReportTextArea.append("NUMBER OF TICKETS: " + numberValue + "\n");
            ticketReportTextArea.append("TICKET PRICE: " + priceValue + "\n");
            ticketReportTextArea.append("TOTAL TICKET PRICE (with VAT): " + VATValue + "\n");
        } else {
            // Display an error message in case of invalid data
            javax.swing.JOptionPane.showMessageDialog(this, "Invalid data type or empty column", "Input Error", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }
    // Additional actions if required when selecting a movie



    

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        movieName = new javax.swing.JLabel();
        ComboBox = new javax.swing.JComboBox<>();
        numberTickets = new javax.swing.JLabel();
        numberTicketTextField = new javax.swing.JTextField();
        ticketPrice = new javax.swing.JLabel();
        PriceTextField = new javax.swing.JTextField();
        ticketReport = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ticketReportTextArea = new javax.swing.JTextArea();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        exitMenuItem = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        ProcessReportMenuItem = new javax.swing.JMenuItem();
        ClearMenuItem = new javax.swing.JMenuItem();
        SaveReportMenuItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ESTATE AGENT REPORT");

        movieName.setText("MOVIE:");

        ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Napoleon", "Oppenheimer", "Damsel" }));
        ComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxActionPerformed(evt);
            }
        });

        numberTickets.setText("NUMBER OF TICKETS:");

        numberTicketTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                numberTicketTextFieldActionPerformed(evt);
            }
        });

        ticketPrice.setText("TICKET PRICE:");

        PriceTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PriceTextFieldActionPerformed(evt);
            }
        });

        ticketReport.setText("TICKET REPORT:");

        ticketReportTextArea.setColumns(20);
        ticketReportTextArea.setRows(5);
        jScrollPane1.setViewportView(ticketReportTextArea);

        jMenu1.setText("File");

        exitMenuItem.setText("Exit");
        exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitMenuItemActionPerformed(evt);
            }
        });
        jMenu1.add(exitMenuItem);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Tools");

        ProcessReportMenuItem.setText("Process Report");
        ProcessReportMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ProcessReportMenuItemActionPerformed(evt);
            }
        });
        jMenu2.add(ProcessReportMenuItem);

        ClearMenuItem.setText("Clear");
        ClearMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearMenuItemActionPerformed(evt);
            }
        });
        jMenu2.add(ClearMenuItem);

        SaveReportMenuItem.setText("Save Report");
        SaveReportMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveReportMenuItemActionPerformed(evt);
            }
        });
        jMenu2.add(SaveReportMenuItem);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(ticketReport, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(192, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane1)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(movieName, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(ticketPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(numberTickets, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(numberTicketTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(PriceTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(ComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(15, 15, 15))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(movieName, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(numberTickets)
                    .addComponent(numberTicketTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ticketPrice)
                    .addComponent(PriceTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ticketReport, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(55, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void PriceTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PriceTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PriceTextFieldActionPerformed

    private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMenuItemActionPerformed
        System.exit(0);// this code ends the application when called on 
    }//GEN-LAST:event_exitMenuItemActionPerformed

    private void ProcessReportMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ProcessReportMenuItemActionPerformed
        ProcessInfomationButton();// calls the method that was done above 
    }//GEN-LAST:event_ProcessReportMenuItemActionPerformed

    private void ClearMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearMenuItemActionPerformed
       // resets the textfields so they can accept new information 
        
        numberTicketTextField.setText(null);
        ticketReportTextArea.setText(null);//https://www.youtube.com/watch?v=j1l0Q-P60Rk  - code was adapted from video (www.youtube.com, n.d.)
        PriceTextField.setText(null);
        ComboBox.getSelectedIndex();
    }//GEN-LAST:event_ClearMenuItemActionPerformed

    private void SaveReportMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveReportMenuItemActionPerformed
        //gets the information that is stored in the text area 
       String info = ticketReportTextArea.getText() ;
        try {
            FileWriter writer = new FileWriter("report.txt") ;// this is where the text file is created and called upon
            writer.write(info);
            writer.close();
        }
        catch (IOException ex) {
            Logger.getLogger(PROGQ2GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        //https://www.geeksforgeeks.org/java-program-to-write-into-a-file/  - (GeeksforGeeks, 2021) code was adapted to send to text file
    }//GEN-LAST:event_SaveReportMenuItemActionPerformed

    private void ComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboBoxActionPerformed

    private void numberTicketTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_numberTicketTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_numberTicketTextFieldActionPerformed

    /**
     * @param args the command line arguments
     */
      public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PROGQ2GUI().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem ClearMenuItem;
    private javax.swing.JComboBox<String> ComboBox;
    private javax.swing.JTextField PriceTextField;
    private javax.swing.JMenuItem ProcessReportMenuItem;
    private javax.swing.JMenuItem SaveReportMenuItem;
    private javax.swing.JMenuItem exitMenuItem;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel movieName;
    private javax.swing.JTextField numberTicketTextField;
    private javax.swing.JLabel numberTickets;
    private javax.swing.JLabel ticketPrice;
    private javax.swing.JLabel ticketReport;
    private javax.swing.JTextArea ticketReportTextArea;
    // End of variables declaration//GEN-END:variables

    private void ProcessInfomationButton() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

   
}
