package progq1;

public class PROGQ1 {

    public static void main(String[] args) {

        String[] movieNames = {"Napoleon", "Oppenheimer"}; // Array that stores movie names
        String[] months = {"JAN", "FEB", "MAR"}; // Array that stores months

        // 2D Array to store movie sales
        double[][] movieSales = { 
            {3000, 1500, 1700},  // Sales for "Napoleon"
            {3500, 1200, 1600}   // Sales for "Oppenheimer"
        };

        PROGQ1 report = new PROGQ1();

        // Displaying the report header
        System.out.println("MOVIE TICKET SALES REPORT - 2024");
        System.out.printf("%-15s", "Movie");
        for (String month : months) {
            System.out.printf("%-15s", month);
        }
        System.out.println("\n------------------------------------------------------------");

        // Loop to display movie sales data
        for (int i = 0; i < movieNames.length; i++) {
            System.out.printf("%-15s", movieNames[i]);
            for (int j = 0; j < movieSales[i].length; j++) {
                System.out.printf("%-15.2f", movieSales[i][j]);
            }
            System.out.println();
        }

        System.out.println();

        // Calculate and display total sales for each movie
        for (int i = 0; i < movieSales.length; i++) {
            double totalSales = report.calculateTotalSales(movieSales[i]);
            System.out.println("Total movie sales for " + movieNames[i] + ": " + totalSales);
        }

        System.out.println();

        // Find and display the top-performing movie
        int topPerformingMovie = report.findTopPerformingMovie(movieSales);
        System.out.println("Top performing movie: " + movieNames[topPerformingMovie]);
    }

    // Method to calculate total sales for a movie
    public double calculateTotalSales(double[] monthlySales) {
        double total = 0;
        for (double sales : monthlySales) {
            total += sales;
        }
        return total;
    }

    // Method to find the top-performing movie based on total sales
    public int findTopPerformingMovie(double[][] movieSales) {
        int TopMovie = 0;
        double highestSales = calculateTotalSales(movieSales[0]);

        for (int i = 1; i < movieSales.length; i++) {
            double totalSales = calculateTotalSales(movieSales[i]);
            if (totalSales > highestSales) {
                highestSales = totalSales;
                TopMovie = i;
            }
        }
        return TopMovie;
        
        
//Java 2D arrays 🚚
//Bro Code-2020
//https://www.youtube.com/watch?v=alwukGslBG8
//12 November 2024
    }
}
