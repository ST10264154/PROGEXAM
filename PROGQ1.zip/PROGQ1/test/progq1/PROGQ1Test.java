/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package progq1;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author whitb
 */
public class PROGQ1Test {
    
    private PROGQ1 report;

    @BeforeEach
    public void setUp() {
        report = new PROGQ1();
    }

    @Test
    public void CalculateTotalSales_ReturnsExpectedTotalSales() {
        // Arrange
        double[] napoleonSales = {3000, 1500, 1700};
        double expectedTotal = 6200;

        // Act
        double totalSales = report.calculateTotalSales(napoleonSales);

        // Assert
        assertEquals(expectedTotal, totalSales, 0.01, "Total sales should be 6200 for Napoleon.");
    }

    @Test
    public void TopMovieSales_ReturnsTopMovie() {
        // Arrange
        double[][] movieSales = {
            {3000, 1500, 1700},  // Napoleon total: 6200
            {3500, 1200, 1600}   // Oppenheimer total: 6300
        };
        int expectedTopMovieIndex = 1;

        // Act
        int topMovieIndex = report.findTopPerformingMovie(movieSales);

        // Assert
        assertEquals(expectedTopMovieIndex, topMovieIndex, "Top movie index should be 1 (Oppenheimer).");
    }
}


